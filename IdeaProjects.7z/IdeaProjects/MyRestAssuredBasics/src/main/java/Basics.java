import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;


public class Basics {

    //validate the Add Place api is Working as expected

    //given -  all input details
    //when -  submit the api
    //then -  validation of response

    RestAssured.baseURI = "https://rahulshettyacademy.com";
    given()




}
